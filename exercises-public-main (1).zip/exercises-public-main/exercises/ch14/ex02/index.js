export class MyArrayLike {
  // TODO
}

export class MyArray extends Array {
  constructor(items) {
    super(...items);
  }

  // TODO
}
