const elem = document.querySelector("#target");
elem.innerHTML = "a";
