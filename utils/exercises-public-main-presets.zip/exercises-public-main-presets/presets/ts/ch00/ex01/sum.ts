export function sum(x: number, y: number) {
  return x + y;
}
