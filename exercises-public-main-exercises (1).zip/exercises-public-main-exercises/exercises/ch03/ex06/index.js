export function substring(str, indexStart, indexEnd) {
  // TODO: ここを実装しなさい
  return "TODO";
}

export function slice(str, indexStart, indexEnd) {
  // TODO: ここを実装しなさい
  return "TODO";
}

export function padStart(str, targetLength, padString) {
  // TODO: ここを実装しなさい
  return "TODO";
}

export function trim(str) {
  // TODO: ここを実装しなさい
  return "TODO";
}
